Z důvodu velikosti a v neni zahrnuta slozka node_modules, ktere treba dostahovat pomoci npm (npm install). Navod na pouziti npm je soucasti README.md ve Frontend casti


Prihlasovaci udaje:

Admin - dostupne vse

Username: Admin
Heslo: pw


ostani uzivatele

Username: Honza, Marek, Eliska, Market, Terka
Heslo: heslo


Odkaz Github:

https://github.com/Zd3n1/BP2024.git


Odkaz na image pro Raspberry Pi:

https://owncloud.cesnet.cz/index.php/s/WVG22Bg5r5um04U