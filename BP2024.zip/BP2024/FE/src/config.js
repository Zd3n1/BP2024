export default {
    backendUrl: 'http://localhost:4000',
    server: '192.168.0.178',
    apiKey: '9D921B1F7A2448E59A10A17EB7834010',
    stream: 'http://192.168.0.178/webcam/?action=stream'
}