<template>
    <router-view/>
</template>

<script>
export default {
  name: "AuthSection",
}
</script>

<style scoped>
</style>