<template>
  <h1 class="d-flex align-center mb-4">
    Admin
  </h1>
</template>


<script>
  export default {
    name: "AdminView",
  };
</script>