CREATE TABLE IF NOT EXISTS practice
(
    practice_id integer primary key autoincrement

);